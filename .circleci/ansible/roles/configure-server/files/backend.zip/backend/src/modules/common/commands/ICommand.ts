import { ICommand as command } from '@nestjs/cqrs';

export interface ICommand extends command {}
